from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes


async def log(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    file = open ('log.csv', 'a')
    file.write(f'{update.effective_user.first_name} , {update.message.text}')
    file.close()
  